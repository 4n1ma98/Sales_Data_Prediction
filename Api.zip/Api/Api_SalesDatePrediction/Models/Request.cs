﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class GetAllPredictionsRequest
    {
        public int PageNumber { get; set; } = 1;
        public int RowPerPage { get; set; } = 10;
        public string Customer { get; set; } = string.Empty;
    }

    public class GetAllOrdersRequest
    {
        public int PageNumber { get; set; } = 1;
        public int RowPerPage { get; set; } = 10;
        public string Customer { get; set; } = string.Empty;
    }

    public class CreateOrderRequest
    {
        public int CustId { get; set; }
        public int EmpId { get; set; }
        public int ShipperId { get; set; }
        public string Freight { get; set; } = default!;
        public string ShipName { get; set; } = default!;
        public string ShipAddress { get; set; } = default!;
        public string ShipCity { get; set; } = default!;
        public string ShipPostalCode { get; set; } = default!;
        public string ShipCountry { get; set; } = default!;
        public List<ProductOrder> Products { get; set; } = default!;
    }

    public class ProductOrder
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = default!;
        public int Count { get; set; }
    }
}
