﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.dto
{
    public class OrderDTO
    {
        public int OrderId { get; set; }
        public string RequiredDate { get; set; } = default!;
        public string ShippedDate { get; set; } = default!;
        public string ShipName { get; set; } = default!;
        public string ShipAddress { get; set; } = default!;
        public string ShipCity { get; set; } = default!;
    }
}
