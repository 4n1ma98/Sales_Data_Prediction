﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.dto
{
    public class PredictionDTO
    {
        public string CustomerName { get; set; } = default!;
        public string LastOrderDate {  get; set; } = default!;
        public string NextPredictedOrder {  get; set; } = default!;
    }
}
