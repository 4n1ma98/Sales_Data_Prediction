using DataAccess;
using Business.Prediction;
using Business.Prediction.Contract;
using Business.Global.Contacts;
using Business.Global;
using Business.Order.Contract;
using Business.Order;
using Business.Customer.Contract;
using Business.Customer;
using Business.Employee.Contract;
using Business.Employee;
using Business.Product.Contract;
using Business.Product;
using Business.Shipper.Contract;
using Business.Shipper;

var builder = WebApplication.CreateBuilder(args);

// Configurar servicios de CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngularApp", builder =>
        builder.WithOrigins("http://localhost:4200")
               .AllowAnyMethod()
               .AllowAnyHeader()
               .AllowCredentials());
});

builder.Services.AddControllers();

builder.Services.AddSingleton<DBContext>();
builder.Services.AddScoped<IErrorCode, ErrorCode>();
builder.Services.AddScoped<ICustomerListGetter, CustomerListGetter>();
builder.Services.AddScoped<IEmployeeListGetter, EmployeeListGetter>();
builder.Services.AddScoped<IOrderCreator, OrderCreator>();
builder.Services.AddScoped<IOrderDetailsCreator, OrderDetailsCreator>();
builder.Services.AddScoped<IOrderListGetter, OrderListGetter>();
builder.Services.AddScoped<IProductListGetter, ProductListGetter>();
builder.Services.AddScoped<IShipperListGetter, ShipperListGetter>();
builder.Services.AddScoped<IPredictionDataFetcher, PredictionDataFetcher>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.UseCors("AllowAngularApp");

app.MapControllers();

app.Run();
