﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;
using Business.Prediction.Contract;

namespace Api_SalesDatePrediction.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PredictionController : ControllerBase
    {
        private readonly IPredictionDataFetcher _predictionDataFetcher;

        public PredictionController(IPredictionDataFetcher predictionDataFetcher)
        {
            _predictionDataFetcher = predictionDataFetcher;
        }

        [HttpPost("[action]")]
        public Response GetAll(GetAllPredictionsRequest request)
        {
            Response response = _predictionDataFetcher.GetAllPredictions(request.PageNumber, request.RowPerPage, request.Customer);

            return response;
        }
    }
}
