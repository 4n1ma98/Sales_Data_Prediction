﻿using Business.Shipper.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;

namespace Api_SalesDatePrediction.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShipperController : ControllerBase
    {
        private readonly IShipperListGetter _shipperListGetter;

        public ShipperController(IShipperListGetter shipperListGetter)
        {
            _shipperListGetter = shipperListGetter;
        }

        [HttpGet("[action]")]
        public Response GetAll()
        {
            Response response = _shipperListGetter.GetAllShippers();

            return response;
        }
    }
}
