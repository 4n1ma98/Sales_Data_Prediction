﻿using Business.Order.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;

namespace Api_SalesDatePrediction.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderListGetter _orderListGetter;
        private readonly IOrderCreator _orderCreator;
        private readonly IOrderDetailsCreator _orderDetailsCreator;

        public OrderController(IOrderListGetter orderListGetter, IOrderCreator orderCreator, IOrderDetailsCreator orderDetailsCreator)
        {
            _orderListGetter = orderListGetter;
            _orderCreator = orderCreator;
            _orderDetailsCreator = orderDetailsCreator;
        }

        [HttpPost("[action]")]
        public Response GetAll(GetAllOrdersRequest request)
        {
            Response response = _orderListGetter.GetOrders(request.PageNumber, request.RowPerPage, request.Customer);

            return response;
        }

        [HttpPost("[action]")]
        public Response CreateOrder(CreateOrderRequest request)
        {
            Response response = _orderCreator.CreateOrder(request.CustId, request.EmpId, request.ShipperId, request.Freight, request.ShipName, request.ShipAddress, request.ShipCity, request.ShipPostalCode, request.ShipCountry);
            response = _orderDetailsCreator.ManageOrderDetails(request.Products, (int)response.AdditionalData!);
            return response;
        }
    }
}
