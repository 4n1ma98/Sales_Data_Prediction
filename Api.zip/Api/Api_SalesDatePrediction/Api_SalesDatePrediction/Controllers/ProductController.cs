﻿using Business.Product.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;

namespace Api_SalesDatePrediction.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductListGetter _productListGetter;

        public ProductController(IProductListGetter productListGetter)
        {
            _productListGetter = productListGetter;
        }

        [HttpGet("[action]")]
        public Response GetAll()
        {
            Response response = _productListGetter.GetAllProducts();

            return response;
        }
    }
}
