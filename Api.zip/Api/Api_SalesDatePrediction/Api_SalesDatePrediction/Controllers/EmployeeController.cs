﻿using Business.Employee.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;

namespace Api_SalesDatePrediction.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeListGetter _employeeListGetter;

        public EmployeeController(IEmployeeListGetter employeeListGetter)
        {
            _employeeListGetter = employeeListGetter;
        }

        [HttpGet("[action]")]
        public Response GetAll()
        {
            Response response = _employeeListGetter.GetAllEmployees();

            return response;
        }
    }
}
