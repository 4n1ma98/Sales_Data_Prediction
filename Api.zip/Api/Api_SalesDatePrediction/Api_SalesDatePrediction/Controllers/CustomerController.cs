﻿using Business.Customer.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;

namespace Api_SalesDatePrediction.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerListGetter _customerListGetter;

        public CustomerController(ICustomerListGetter customerListGetter)
        {
            _customerListGetter = customerListGetter;
        }

        [HttpGet("[action]")]
        public Response GetAll()
        {
            Response response = _customerListGetter.GetAllCustomers();

            return response;
        }
    }
}
