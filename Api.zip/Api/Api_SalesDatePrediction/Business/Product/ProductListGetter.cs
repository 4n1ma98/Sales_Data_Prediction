﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contacts;
using Business.Product.Contract;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;
using Models.dto;

namespace Business.Product
{
    public class ProductListGetter : IProductListGetter
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;

        public ProductListGetter(DBContext dBContext, IConfiguration config, IErrorCode errorCode)
        {
            _dBContext = dBContext;
            _config = config;
            _errorCode = errorCode;
        }

        public Response GetAllProducts()
        {
            List<ProductDTO> productList;

            var parameters = new
            {
                Option = 5
            };

            try
            {
                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    productList = _context.Query<ProductDTO>("SP_SalesDataPrediction", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure).ToList();

                return _errorCode.GetError(0, productList);
            }
            catch (Exception ex)
            {
                return _errorCode.GetError(-999);
            }
        }
    }
}
