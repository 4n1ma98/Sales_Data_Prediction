﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace Business.Global.Contacts
{
    public interface IErrorCode
    {
        Response GetError(int idError, object? additionalData = null);
    }
}
