﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Employee.Contract;
using Business.Global;
using Business.Global.Contacts;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;
using Models.dto;

namespace Business.Employee
{
    public class EmployeeListGetter : IEmployeeListGetter
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;

        public EmployeeListGetter(DBContext dBContext, IConfiguration config, IErrorCode errorCode)
        {
            _dBContext = dBContext;
            _config = config;
            _errorCode = errorCode;
        }

        public Response GetAllEmployees()
        {
            List<EmployeeDTO> customerList;

            var parameters = new
            {
                Option = 3
            };

            try
            {
                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    customerList = _context.Query<EmployeeDTO>("SP_SalesDataPrediction", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure).ToList();

                return _errorCode.GetError(0, customerList);
            }
            catch (Exception ex)
            {
                return _errorCode.GetError(-999);
            }
        }
    }
}
