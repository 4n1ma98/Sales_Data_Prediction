﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contacts;
using Business.Order.Contract;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;

namespace Business.Order
{
    public class OrderCreator : IOrderCreator
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;

        public OrderCreator(DBContext dBContext, IConfiguration config, IErrorCode errorCode)
        {
            _dBContext = dBContext;
            _config = config;
            _errorCode = errorCode;
        }

        public Response CreateOrder(int custId, int empId, int shipperId, string freight, string shipName, string shipAddress, string shipCity, string shipPostalCode, string shipCountry)
        {
            int orderId;

            var parameters = new
            {
                Option = 7,
                CustId = custId,
                EmpId = empId,
                ShipperId = shipperId,
                Freight = freight,
                ShipName = shipName,
                ShipAddress = shipAddress,
                ShipCity = shipCity,
                ShipPostalCode = shipPostalCode,
                ShipCountry = shipCountry
            };

            try
            {
                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    orderId = _context.Query<int>("SP_SalesDataPrediction", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure).FirstOrDefault();

                return _errorCode.GetError(0, orderId);
            }
            catch (Exception ex)
            {
                return _errorCode.GetError(-999);
            }
        }
    }
}
