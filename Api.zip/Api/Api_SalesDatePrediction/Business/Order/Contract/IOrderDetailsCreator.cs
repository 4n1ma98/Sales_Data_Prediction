﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace Business.Order.Contract
{
    public interface IOrderDetailsCreator
    {
        Response ManageOrderDetails(List<ProductOrder> products, int orderId);
    }
}
