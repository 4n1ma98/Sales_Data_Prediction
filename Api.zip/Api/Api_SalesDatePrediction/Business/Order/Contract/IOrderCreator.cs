﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace Business.Order.Contract
{
    public interface IOrderCreator
    {
        Response CreateOrder(int custId, int empId, int shipperId, string freight, string shipName, string shipAddress, string shipCity, string shipPostalCode, string shipCountry);
    }
}
