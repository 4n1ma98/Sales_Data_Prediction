﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contacts;
using Business.Order.Contract;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;

namespace Business.Order
{
    public class OrderDetailsCreator : IOrderDetailsCreator
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;

        public OrderDetailsCreator(DBContext dBContext, IConfiguration config, IErrorCode errorCode)
        {
            _dBContext = dBContext;
            _config = config;
            _errorCode = errorCode;
        }

        public Response ManageOrderDetails(List<ProductOrder> products, int orderId)
        {
            try
            {
                foreach (var product in products)
                {
                    CreateOrderDetails(product, orderId);
                }

                return _errorCode.GetError(0);
            }
            catch (Exception)
            {
                return _errorCode.GetError(-999);
            }
        }

        public bool CreateOrderDetails(ProductOrder product, int orderId)
        {
            try
            {
                var parameters = new
                {
                    Option = 8,
                    OrderId = orderId,
                    product.ProductId,
                    product.Count
                };

                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    _context.Execute("SP_SalesDataPrediction", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
