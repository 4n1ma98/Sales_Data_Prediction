﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contacts;
using Business.Order.Contract;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;
using Models.dto;

namespace Business.Order
{
    public class OrderListGetter : IOrderListGetter
    {
        private readonly DBContext _dbContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;

        public OrderListGetter(DBContext dBContext, IConfiguration config, IErrorCode errorCode) 
        { 
            _dbContext = dBContext;
            _config = config;
            _errorCode = errorCode;
        }

        public Response GetOrders(int pageNumber, int rowsPerPage, string customer)
        {
            List<OrderDTO> orderList;
            int totalCount = 0;

            try
            {
                var parameters = new
                {
                    Option = 2,
                    Customer = customer
                };

                using (IDbConnection _context = _dbContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    orderList = _context.Query<OrderDTO>("SP_SalesDataPrediction", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure).ToList();

                totalCount = orderList.Count;

                orderList = orderList.Skip((pageNumber - 1) * rowsPerPage)
                                     .Take(rowsPerPage)
                                     .ToList();

                return _errorCode.GetError(0, new { TotalItems = totalCount, OrderList = orderList });
            }
            catch (Exception ex)
            {
                return _errorCode.GetError(-999);
            }
        }
    }
}
