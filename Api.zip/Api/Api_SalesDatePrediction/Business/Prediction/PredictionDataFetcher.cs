﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contacts;
using Business.Prediction.Contract;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;
using Models.dto;

namespace Business.Prediction
{
    public class PredictionDataFetcher : IPredictionDataFetcher
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;

        public PredictionDataFetcher(DBContext dBContext, IConfiguration config, IErrorCode errorCode)
        {
            _dBContext = dBContext;
            _config = config;
            _errorCode = errorCode;
        }

        public Response GetAllPredictions(int pageNumber, int rowsPerPage, string customer)
        {
            try
            {
                List<PredictionDTO> predictionList;
                int totalCount = 0;

                var parameters = new
                {
                    Option = 1,
                    Customer = customer
                };

                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    predictionList = _context.Query<PredictionDTO>("SP_SalesDataPrediction", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure).ToList();

                totalCount = predictionList.Count;

                predictionList = predictionList.Skip((pageNumber - 1) * rowsPerPage)
                                               .Take(rowsPerPage)
                                               .ToList();

                return _errorCode.GetError(0, new { TotalItems = totalCount, PredictionList = predictionList });
            }
            catch (Exception ex)
            {
                return _errorCode.GetError(-999);
            }
        }
    }
}
